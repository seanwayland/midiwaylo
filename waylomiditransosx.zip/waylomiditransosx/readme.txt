www.seanwayland.com
seanwayland@gmail.com

Waylomiditrans
VST plugin

This midi only plugin was made with
https://www.juce.com/

source code is available here
https://github.com/seanwayland/midiwaylo

It was created with OSX 10.12

The component file is an AU and there is a VST

the vst plugin should probably go into

library/audio/plug-ins/vst

and the component into

library/audio/plug-ins/components

In order for me to get it working in Cubase :

create an audio track and stick the waylomiditrans as an insert
create a midi track and route the output of track to the waylomiditrans
create a seperate instrument track and select the waylomiditrans as the input

The plugin uses all notes below middle c ( midi note 60 ) to transpose the top half of the keyboard.

You have to hold a key down below middle C to transpose. Once you lift your finger off it stops transposing.

Any questions seanwayland@gmail.com

Have Fun ! Use responsibly. 



